import React from 'react';
import logo from '../../assets/image.png';

const Logo = () => <img src={logo} alt="logo" width={100} />;

export default Logo;
