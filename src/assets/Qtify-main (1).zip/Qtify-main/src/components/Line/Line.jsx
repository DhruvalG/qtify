import React from 'react';

const Line = () => (
  <hr style={{ margin: '2.5rem 0', border: '1px solid var(--primary-color' }} />
);

export default Line;
